var options={
	center: {lat: 11.19420390014348, lng: 125.18313347849372},
	zoom: 11,

};
element=document.getElementById("map-canvas");
//map
var map=new google.maps.Map(element,options); 



