(function(window,google,mapster){
	//map options
	mapster.MAP_OPTIONS={
		center: {lat: 11.19420390014348, lng: 125.18313347849372},
		zoom: 11,
		scrollwheel:true,		
		mapTypeId: google.maps.MapTypeId.TERRAIN,

	}

}(window,google,window.Mapster ||(window.Mapster={})));