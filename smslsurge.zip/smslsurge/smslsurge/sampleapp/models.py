from django.db import models

# Create your models here.

class Typhoon(models.Model):
	typhoon_id=models.IntegerField(primary_key=True)
	typhoon_name=models.CharField(max_length=100)

	def __str__(self):
		return str(self.typhoon_id) + "\t" + self.typhoon_name

class SurgeEvent(models.Model):
	typhoon_id=models.ForeignKey(Typhoon,on_delete=models.CASCADE)
	event_id=models.IntegerField(unique=True)
	area=models.CharField(max_length=100)

	def __str__(self):
		return str(self.typhoon_id) + "\t" + str(self.event_id)


class MaxSurge(models.Model):
	event_id=models.ForeignKey(SurgeEvent,on_delete=models.CASCADE)
	MaxSurge_id=models.IntegerField(unique=True)
	kmlFile=models.CharField(max_length=200)


	def __str__(self):
		return str(self.event_id) + "\t" + str(self.MaxSurge_id) + "\t" + str(self.kmlFile)

class TimeSeries(models.Model):
	event_id=models.ForeignKey(SurgeEvent,on_delete=models.CASCADE)
	date_time=models.DateTimeField(auto_now=False)
	customFile=models.CharField(max_length=200)
	gridFile=models.CharField(max_length=200)


	def __str__(self):
		return str(self.event_id.event_id) + "\t" + str(self.event_id.typhoon_id.typhoon_name) + "\t" + str(self.date_time)
