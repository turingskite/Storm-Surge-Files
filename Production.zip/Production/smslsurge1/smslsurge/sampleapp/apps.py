from django.apps import AppConfig


class SampleappConfig(AppConfig):
    name = 'sampleapp'
