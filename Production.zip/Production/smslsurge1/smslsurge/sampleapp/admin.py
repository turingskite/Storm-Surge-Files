from django.contrib import admin
from .models import *


# Register your models here.
admin.site.register(Typhoon)
admin.site.register(SurgeEvent)
admin.site.register(SurgeFrame)
admin.site.register(MaxSurge)

